# Toilet Escape

Static one-file game. No build step.

## Deploy on Vercel
1. Upload this folder (or the ZIP contents) to a GitHub repo, or drag it into Vercel's "Add New > Project" import / use `vercel` CLI.
2. Framework Preset: **Other**. Build Command: empty. Output Directory: empty (root).
3. Deploy.

## AdSense later
In `index.html`, find the two comments `Ad slot (top)` and `Ad slot (bottom)` and paste your AdSense `<ins>` units inside the `<div class="ad">` blocks. Add the AdSense script tag in `<head>`.

## Production notes
- `vercel.json` sets a Content Security Policy and security headers. The CSP already allows common Google AdSense domains. If an ad does not show, check the browser console for blocked domains and add them to the CSP.
- Vercel's free Hobby plan is for non-commercial use. Check Vercel's terms before showing ads, you may need the Pro plan.
- Roll back any time: Vercel dashboard > Deployments > pick an older one > Promote to Production.
- Optional later: add an `ads.txt` file in the root once AdSense gives you one.

## AdSense setup (done in code)
- Your AdSense script and publisher ID are already in `index.html`.
- `ads.txt` is included for AdSense.
- In AdSense, create two display ad units, then replace `TOP_AD_SLOT_ID` and `BOTTOM_AD_SLOT_ID` in `index.html` with the `data-ad-slot` numbers AdSense gives you.
